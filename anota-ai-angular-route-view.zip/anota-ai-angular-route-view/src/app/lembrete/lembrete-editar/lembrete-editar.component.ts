import { Component, OnInit,Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { Lembrete } from '../lembrete.model';
import { LembreteService } from '../lembrete.service';
import { Subscription } from 'rxjs';
import { NgForm } from '@angular/forms';




export interface DialogData {
  lembreteId: string;
}

@Component({
  selector: 'app-lembrete-editar',
  templateUrl: './lembrete-editar.component.html',
  styleUrls: ['./lembrete-editar.component.css']
})
export class LembreteEditarComponent implements OnInit {

  lembreteSubscription: Subscription;
  lembrete: Lembrete = {
    _id:'',
    criadoem: null,
    prazo: null,
    descricao: '',
    titulo: ''
  };
  lembreteId: string;
  msg: "";

  constructor(
    public dialogRef: MatDialogRef<LembreteEditarComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    public lembreteService: LembreteService,
    ) {}


  ngOnInit(): void {
    console.log('onInit...');
    console.log('lembreteId',this.data.lembreteId);
    this.consultarLembrete(this.data.lembreteId);
  }
  ngOnDestroy(): void {
    this.lembreteSubscription.unsubscribe();
  }


  onNoClick(): void {
    this.dialogRef.close();
  }

  consultarLembrete(id: string): void{
    this.lembreteService.buscarLembreteId(id);
  

    this.lembreteSubscription = this.lembreteService.getLembretesAtualizadaObservable().subscribe((lembrete: Lembrete) => {
      this.lembrete = lembrete;
      console.log('object lembrete', this.lembrete);
    });


  }
  atualizarUsuario(form: NgForm){
    if (form.invalid) {
      console.log("formulario invalido"); 
      return;
    }
    console.log("formulario valido");  
    this.lembreteService.atualizarLembrete(this.lembrete._id,this.lembrete.titulo,this.lembrete.criadoem,form.value.prazo,this.lembrete.descricao);   
    this.dialogRef.close();
  }


}
