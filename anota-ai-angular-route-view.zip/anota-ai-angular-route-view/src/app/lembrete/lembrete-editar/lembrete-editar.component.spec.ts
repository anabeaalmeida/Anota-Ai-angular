import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LembreteEditarComponent } from './lembrete-editar.component';

describe('LembreteEditarComponent', () => {
  let component: LembreteEditarComponent;
  let fixture: ComponentFixture<LembreteEditarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LembreteEditarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LembreteEditarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
