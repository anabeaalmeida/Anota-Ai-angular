import { Injectable } from '@angular/core';
import { Lembrete } from './lembrete.model';
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {MatSnackBar} from '@angular/material/snack-bar';


@Injectable({
  providedIn: 'root'
})
export class LembreteService {
  constructor(
    private httpClient: HttpClient,
    private _snackBar: MatSnackBar) { }

  private listaLembretesAtualizada = new Subject<Lembrete[]>();

  private lembretes: Lembrete[] = [];

  private lembrete = new Subject<Lembrete>();

  getLembretes(): void {
    this.httpClient.get<{ mensagem: string, lembretes: Lembrete[] }>(
      'api/lembretes'
    ).subscribe((dados) => {
      
      this.lembretes = dados.lembretes
      console.log('lembretes',this.lembretes);
      this.listaLembretesAtualizada.next([...this.lembretes])
    })
  }

  adicionarLembrete(titulo: string, criadoem: Date, prazo: Date, descricao: string): void {
    const lembrete: Lembrete = {
      _id: "",
      titulo: titulo,
      criadoem: criadoem,
      prazo: prazo,
      descricao: descricao
    };
    this.httpClient.post<{ mensagem: string, lembrete: Lembrete}>(
      'api/lembretes',
      lembrete
    ).subscribe((dados) => {
      console.log('adicionarLembrete-->',dados)
      this.lembretes.push(dados.lembrete);
      this.listaLembretesAtualizada.next([...this.lembretes]);
      this.openSnackBar("Lembrete inserido com sucesso","Done");
    })
  }
  atualizarLembrete(id: string, titulo: string, criadoem: Date, prazo: Date, descricao: string): void {
    const lembrete: Lembrete = {
      _id:id,
      titulo: titulo,
      criadoem: criadoem,
      prazo: prazo,
      descricao: descricao
    };
    this.httpClient.put<{ mensagem: string, lembrete: Lembrete}>(
      'api/lembretes/'+id,
      lembrete
    ).subscribe((dados) => {
      console.log('atualizando lembrete-->',dados)
      //this.lembretes.push(dados.lembrete);
      //this.listaLembretesAtualizada.next([...this.lembretes]);
      this.getLembretes();
      this.openSnackBar("Lembrete atualizado com sucesso","Done");
    })
  }

  removerLembrete(id: string): void {
    this.httpClient.delete<{ mensagem: string}>(
      'api/lembretes/'+id
    ).subscribe((dados) => {
      console.log('lembrete removido-->',dados)


      this.getLembretes();
      this.openSnackBar("Lembrete removido com sucesso","Done");

    })

  }

  buscarLembreteId(id: string): void {
    this.httpClient.get<{ lembrete: Lembrete}>(
      'api/lembretes/'+id
    ).subscribe((lembrete) => {
      
      console.log('lembrete retornado-->',lembrete);
      this.lembrete.next(lembrete.lembrete);
    });

  }




  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }

  getListaDeLembretesAtualizadaObservable() {
    return this.listaLembretesAtualizada.asObservable();
  }

  getLembretesAtualizadaObservable() {
    return this.lembrete.asObservable();
  }
  
}
