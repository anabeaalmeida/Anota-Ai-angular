//import { Component, OnInit, Output,EventEmitter } from '@angular/core';
//import { Lembrete } from '../lembrete.model';
import { Component,Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LembreteService } from '../lembrete.service';
import { Lembrete } from '../lembrete.model';



@Component({
  selector: 'app-lembrete-inserir',
  templateUrl: './lembrete-inserir.component.html',
  styleUrls: ['./lembrete-inserir.component.css']
})
export class LembreteInserirComponent {

  lembrete: Lembrete = {
    _id: "",
    titulo : "",
    prazo: new Date(),
    criadoem : new Date(),
    descricao : ''

  };

  constructor(
    public lembreteService: LembreteService) {

  }



  onAdicionarLembrete(form: NgForm) {
    if (form.invalid) return;
    this.lembreteService.adicionarLembrete(
      form.value.titulo,
      form.value.criadoem,
      form.value.prazo,
      form.value.descricao
    );

    this.lembrete.descricao = "";
    this.lembrete.titulo = "";

  }

  
}
