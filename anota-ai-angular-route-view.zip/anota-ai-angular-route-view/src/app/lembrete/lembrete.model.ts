export interface Lembrete {
  _id: string;
  titulo: string;
  criadoem: Date;
  prazo: Date;
  descricao: string;
}
