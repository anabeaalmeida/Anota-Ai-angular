import { Component, OnInit, OnDestroy } from '@angular/core';
import { Lembrete } from '../lembrete.model';
import { LembreteService } from '../lembrete.service';
import { Subscription } from 'rxjs';
import {MatDialog} from '@angular/material/dialog';
import {LembreteEditarComponent} from '../lembrete-editar/lembrete-editar.component'


@Component({
  selector: 'app-lembrete-lista',
  templateUrl: './lembrete-lista.component.html',
  styleUrls: ['./lembrete-lista.component.css']
})
export class LembreteListaComponent implements OnInit, OnDestroy {

  lembretes: Lembrete[] = [];
  private lembretesSubscription: Subscription;
  currentDate: Date = new Date();

  constructor(
    public lembreteService: LembreteService,
    public dialog: MatDialog) {

  }

  ngOnInit(): void {
    this.lembreteService.getLembretes();
    this.lembretesSubscription = this.lembreteService.getListaDeLembretesAtualizadaObservable().subscribe((lembretes: Lembrete[]) => {
      this.lembretes = lembretes;
    });
  }

  compareDate(prazo){

    let d2 = new Date(prazo); 
    let d1 = this.currentDate;
    //compare only date not hours
    d1.setHours(0,0,0,0)
    d2.setHours(0,0,0,0)
    // console.log('d1',d1);
    // console.log('d2',d2);
    

    let same = d1.getTime() === d2.getTime();
    if (same) return 'status-due-today';

    // Check if the first is greater than second
    if (d1 > d2) return 'status-late';
  
    // Check if the first is less than second
    if (d1 < d2) return 'status-on-time';


    
    return true;
  }


  deleteLembrete(id: string){
    this.lembreteService.removerLembrete(id);
    this.lembretesSubscription.remove
  }

  ngOnDestroy(): void {
    this.lembretesSubscription.unsubscribe();
  }

  openDialog(id:string): void {
    const dialogRef = this.dialog.open(LembreteEditarComponent, {
      width: '650px',
      data: {lembreteId: id}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      let animal: string;
      animal = result;
      console.log('animal return', animal);
    });
  }


}
