export interface Usuario {
  nome: string;
  senha: string;
  genero: string;
  telefone: string;
  email: string;
}
