import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, NgForm } from '@angular/forms';
import {Usuario} from './usuario.model'
import { UsuarioService } from "./usuario.service";

@Component({
  selector: 'app-usuario-cadastro',
  templateUrl: './usuario-cadastro.component.html',
  styleUrls: ['./usuario-cadastro.component.css']
})
export class UsuarioCadastroComponent implements OnInit {

  constructor(
    private usuarioService: UsuarioService
  ) { }
  hide = true;
  msg = "";
  usuario: Usuario = {
    nome: '',
    email: '',
    genero: 'I',
    senha: '',
    telefone: '(11) '

  }


  ngOnInit(): void {
  }

  cadastrarUsuario(form: NgForm){

    if (form.invalid){ 
      this.msg = "campos obrigatórios.";
      return;
    }else{
      this.msg ="";
    }
    this.usuarioService.cadastrarUsuario(this.usuario);

  }



}
