import { Injectable } from '@angular/core';
import { Usuario } from './usuario.model';
import { from, Subject } from 'rxjs';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Router} from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar';


@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  constructor(
    private httpClient: HttpClient,
    private router: Router,
    private _snackBar: MatSnackBar    ) { }

  
  

  cadastrarUsuario(usuario: Usuario): void {
    
    console.log('usuario cadastro', usuario);
    this.httpClient.post<Usuario>(
      'api/usuarios',
      usuario
    ).subscribe((dados) => {
      console.log('usuario cadastrado com sucesso -->',dados)
      this.router.navigate(['/login']);
      this.openSnackBar("Usuário Cadastrado com sucesso.", "Ok");
  
    },
    (err: HttpErrorResponse) => {
      if (err.error instanceof Error) {
        //A client-side or network error occurred.				 
        console.log('An error occurred:', err.error.message);
        this.router.navigate(['/error']);
      } else {
        
        //Backend returns unsuccessful response codes such as 404, 500 etc.				 
        console.log('Backend returned status code: ', err.status);
        console.log('Response body:', err.error);
        this.router.navigate(['/error']);

      }
    })
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 5000,
    });
  }


}
