import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginService } from './login.service';


@Component({
  selector: 'app-usuario-login',
  templateUrl: './usuario-login.component.html',
  styleUrls: ['./usuario-login.component.css']
})
export class UsuarioLoginComponent implements OnInit {
  


  constructor(
    public loginService: LoginService) { }
  
  msg: String = '';


  ngOnInit(): void {
  }

  onLogin(form: NgForm) {
    console.log('form..', form);
    if (form.invalid){ 
      this.msg = "campos obrigatórios.";
      return;
    }else{
      this.msg = "";
    }
    this.loginService.login(
      form.value.usuario,
      form.value.senha
    );

    //form.resetForm();
  }
 
}
