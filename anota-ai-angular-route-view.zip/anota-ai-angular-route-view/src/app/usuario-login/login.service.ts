import { Injectable } from '@angular/core';
import { Login } from './login.model';
import { from, Subject } from 'rxjs';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar';
import {AuthGuardService} from '../guards/auth-guard.service'


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  constructor(
    private httpClient: HttpClient,
    private router: Router,
    private _snackBar: MatSnackBar,
    private authGuard: AuthGuardService
    ) { }

  
  login(usuario: string, senha: string): void {
    const usuarioLogin : Login = {
      nome: usuario,
      senha: senha
    };
    
    console.log('usuario login', usuarioLogin);
    this.httpClient.post<{mensagem: string, usuario: Login}>(
      'api/login',
      usuarioLogin
    ).subscribe((dados) => {
      console.log('login sucesso -->',dados.usuario)
      this.authGuard.doLogin(dados.usuario.nome);
      this.router.navigate(['/home']);
      //this.lembretes.push(lembrete);
      //this.listaLembretesAtualizada.next([...this.lembretes]);
    },
    (err: HttpErrorResponse) => {
      if (err.error instanceof Error) {
        //A client-side or network error occurred.				 
        console.log('An error occurred:', err.error.message);
        this.router.navigate(['/error']);
      } else {
        
        //Backend returns unsuccessful response codes such as 404, 500 etc.				 
        console.log('Backend returned status code: ', err.status);
        console.log('Response body:', err.error);
        this.openSnackBar("Usuário e/ou senha inválidos. Tente novamente.", "Ok");

      }
    })
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 15000,
    });
  }


}
