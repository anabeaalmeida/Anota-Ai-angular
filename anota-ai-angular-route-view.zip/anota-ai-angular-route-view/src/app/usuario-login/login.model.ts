export interface Login {
  nome: string;
  senha: string;
}
